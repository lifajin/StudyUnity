namespace FastProfiler
{
    //事件监听注入
    public static partial class CodeInject
    {
        
    }
}